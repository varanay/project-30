
### Features of Stage 2:
##### On Space button pressed, player gets a second chance to play
##### Blocks vanish on coming in contact with my slingshot





